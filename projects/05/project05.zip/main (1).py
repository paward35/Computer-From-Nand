for n in range(0,24577):
    print("{:016b}".format(n) + ": " + str(n)) 