for n in range(0,24577):
    print(str(n) + ": " + "{0:b}".format(n, '016b')) 