# A (rough) implementation of the SIR model
The SIR model is a simple model of differential equations for modeling an epidemic. This project is a very simple implementation of it.
See e.g. https://en.wikipedia.org/wiki/Compartmental_models_in_epidemiology#The_SIR_model or this numberphile video https://www.youtube.com/watch?v=k6nLfCbAzgo
for more details on it. 

Basically the implementation demonstrates some math, loops and the drawing of functions (and if time permits some interactivity).


