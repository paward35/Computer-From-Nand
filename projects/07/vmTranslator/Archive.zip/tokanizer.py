
def tokanize(code):
    return [line.split(' ') for line in code]
